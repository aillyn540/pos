<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "ra_pos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$total_amount = $_POST['total_amount'];
$received_amount = $_POST['received_amount'];
$change = $_POST['change'];
$products = $_POST['products']; 

$sql = "INSERT INTO sales (total_amount, received_amount, change, products) 
        VALUES ('$total_amount', '$received_amount', '$change', '$products')";

if ($conn->query($sql) === TRUE) {
    echo 'success';
} else {
    echo 'error';
}

$conn->close();
?>
