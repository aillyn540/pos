<?php
session_start();
$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "ra_pos";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($pass, $row['password'])) {
            $_SESSION['user'] = $user; 
            header("Location: main.php"); 
            exit();
        } else {
            echo "<script>alert('Invalid password.'); window.location.href = 'index.html';</script>";
        }
    } else {
        echo "<script>alert('User does not exist.'); window.location.href = 'index.html';</script>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Registration</title>
    <link rel="stylesheet" href="styles/login.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="images/RA_Vegetables_and_Fruits_Logo.png" alt="Logo">
        </div>

        
        <div class="login-form" id="loginForm">
            <h2>USER LOGIN</h2>
            <form method="POST" action="login.php">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <div class="forgot-password">
                <a href="forgot-password.php">Forgot your password?</a>
            </div>

                <p class="switch-link">
                    Don't have an account? <a href="#" id="showSignup">Sign up</a>
                </p>

                <button type="submit">Login</button>
                <p id="errorMessage"></p>
            </form>
        </div>

       
        <div class="login-form hidden" id="signupForm">
            <h2>USER SIGN UP</h2>
            <form method="POST" action="register.php">
                <label for="signup-username">Username</label>
                <input type="text" id="signup-username" name="username" required>

                <label for="signup-password">Password</label>
                <input type="password" id="signup-password" name="password" required>

                <p class="switch-link">
                    Already have an account? <a href="#" id="showLogin">Login</a>
                </p>

                <button type="submit">Sign Up</button>
            </form>
        </div>
    </div>

    <script src="scripts/login.js"></script>
</body>
</html>
