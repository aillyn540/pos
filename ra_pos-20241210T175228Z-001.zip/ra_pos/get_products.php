<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "ra_pos";


$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';

$sql = "SELECT * FROM stock WHERE 1";


if (!empty($search)) {
    $sql .= " AND name LIKE '%$search%'";
}

if (!empty($category)) {
    $sql .= " AND category = '$category'";
}

$result = $conn->query($sql);


$products = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}
echo json_encode($products);

$conn->close();
?>
