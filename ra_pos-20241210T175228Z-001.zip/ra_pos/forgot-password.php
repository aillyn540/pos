<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="styles/login.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="images/RA_Vegetables_and_Fruits_Logo.png" alt="Logo">
        </div>

        <div class="forgot-password-form">
            <h2>Forgot Password</h2>
            <form action="process-forgot-password.php" method="POST">
                <label for="email">Enter your Email:</label>
                <input type="email" id="email" name="email" required>
                <button type="submit">Send</button>
            </form>
            <p class="switch-link">
                Remembered your password? <a href="index.html">Go back to Login</a>
            </p>
        </div>
    </div>
</body>
</html>
