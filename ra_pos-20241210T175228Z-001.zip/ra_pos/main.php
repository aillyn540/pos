<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS System - Products</title>
    <link rel="stylesheet" href="styles/main.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="sidebar">
            <h2>POS System</h2>
            <ul>
                <li><a href="#" onclick="showSection('products')">🛒Products</a></li>
                <li><a href="#" onclick="showSection('inventory')">📦Inventory</a></li>
                <li><a href="#" onclick="showSection('sales')">📈Sales</a></li>
                <li><a href="logout.php">🚪Logout</a></li>
            </ul>
        </div>

        <div class="main-content" id="main-content">
    <h1>Welcome admin!</h1>
    <p>Select an option from the sidebar.</p>
    <div class="real-time-info">
        <p id="current-time"></p>
        <p id="current-date"></p>
    </div>
</div>


    <script>
        function showSection(section) {
            const content = document.getElementById('main-content');
            content.innerHTML = '';

            if (section === 'products') {
    content.innerHTML = `
        <div class="products-section">
            <h2>Products</h2>
            <div class="search-bar">
                <input type="text" id="search-input" placeholder="Search for a product..." onkeyup="searchProducts(this.value)">
            </div>
            <div id="categories"></div> 
            <div id="product-list"></div> 
            <div id="cart"></div> 
        </div>
    `;
    loadCategories();
}

 else if (section === 'inventory') {
                content.innerHTML = `
                    <div class="inventory-section">
                        <h2>Inventory Management</h2>
                        <form id="inventory-form" method="POST" action="add_to_inventory.php" enctype="multipart/form-data">
                            <label for="category">Category:</label>
                            <input type="text" id="category" name="category" required>

                            <label for="name">Name:</label>
                            <input type="text" id="name" name="name" required>

                            <label for="price">Price:</label>
                            <input type="number" id="price" name="price" step="0.01" required>

                            <label for="image">Image:</label>
                            <input type="file" id="image" name="image" accept="image/*" required>

                            <button type="submit">Add to Inventory</button>
                        </form>
                        <p id="response-message"></p>
                    </div>
                `;
                handleInventoryFormSubmission();
            }
            else if (section === 'sales') { 
        content.innerHTML = `
            <div class="sales-section">
                <h2>Sales</h2>
               
                
            </div>
        `;
    }
    
            
        }

        function clearCart() {
            localStorage.removeItem('cart');
            displayCart();
        }

        function loadCategories() {
    $.ajax({
        url: 'get_categories.php',
        type: 'GET',
        success: function(response) {
            const categories = JSON.parse(response);
            let categoryHtml = `<div class="category-list">`;
            categories.forEach(category => {
                if (category !== "Vegetables and Fruits") { 
                    categoryHtml += `<button class="category-btn" onclick="loadProducts('${category}')">${category}</button>`;
                }
            });
            categoryHtml += `</div>`;
            $('#categories').html(categoryHtml);
            loadProducts(); 
        },
        error: function() {
            alert("Error loading categories");
        }
    });
}

        function loadProducts(category = '') {
            $.ajax({
                url: 'get_products.php',
                type: 'GET',
                data: {
                    category: category
                },
                success: function(response) {
                    const products = JSON.parse(response);
                    products.sort((a, b) => a.name.localeCompare(b.name));

                    let productHtml = '<div class="product-list">';
                    products.forEach(product => {
                        productHtml += `
                            <div class="product-card">
                                <img src="${product.image}" alt="${product.name}">
                                <h3>${product.name}</h3>
                                <p>${product.category}</p>
                                <p>₱${product.price}</p>
                                <button onclick="addToCart(${product.id}, '${product.name}', ${product.price})">Add to Cart</button>
                            </div>
                        `;
                    });
                    productHtml += '</div>';
                    $('#product-list').html(productHtml);
                },
                error: function() {
                    alert("Error loading products");
                }
            });
        }
        function searchProducts(query) {
    $.ajax({
        url: 'get_products.php',
        type: 'GET',
        data: {
            search: query.trim()
        },
        success: function(response) {
            const products = JSON.parse(response);
            products.sort((a, b) => a.name.localeCompare(b.name));

            let productHtml = '<div class="product-list">';
            products.forEach(product => {
                productHtml += `
                    <div class="product-card">
                        <img src="${product.image}" alt="${product.name}">
                        <h3>${product.name}</h3>
                        <p>${product.category}</p>
                        <p>₱${product.price}</p>
                        <button onclick="addToCart(${product.id}, '${product.name}', ${product.price})">Add to Cart</button>
                    </div>
                `;
            });
            productHtml += '</div>';
            $('#product-list').html(productHtml);
        },
        error: function() {
            alert("Error searching products");
        }
    });
}

        

        function addToCart(id, name, price) {
            let cart = JSON.parse(localStorage.getItem('cart') || '[]');
            const productIndex = cart.findIndex(item => item.id === id);

            if (productIndex !== -1) {
                cart[productIndex].quantity++;
            } else {
                const product = {
                    id,
                    name,
                    price,
                    quantity: 1
                };
                cart.push(product);
            }

            localStorage.setItem('cart', JSON.stringify(cart));
            displayCart();
        }

        function displayCart() {
            const cart = JSON.parse(localStorage.getItem('cart') || '[]');
            let cartHtml = `<h3>Your Cart</h3><ul>`;
            let total = 0;
            cart.forEach(item => {
                cartHtml += `
                    <li>${item.name} - ₱${item.price} x ${item.quantity}</li>
                `;
                total += item.price * item.quantity;
            });
            cartHtml += `</ul><h4>Total: ₱${total.toFixed(2)}</h4>`;
            cartHtml += `<button class="clear-cart-btn" onclick="clearCart()">Clear Cart</button>`;
            cartHtml += `<button id="checkout-button" onclick="checkout()">Checkout</button>`;
            $('#cart').html(cartHtml);
        }

        function checkout() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }

    let totalAmount = 0;
    cart.forEach(item => {
        totalAmount += item.price * item.quantity;
    });

    let receivedAmount = parseFloat(prompt("Enter amount received:"));
    if (isNaN(receivedAmount) || receivedAmount < totalAmount) {
        alert("Invalid amount received. Please enter a valid value.");
        return;
    }

    let change = receivedAmount - totalAmount;

    // Save sale to the database
    $.ajax({
        url: 'save_sale.php',
        type: 'POST',
        data: {
            total_amount: totalAmount,
            received_amount: receivedAmount,
            change: change,
            products: JSON.stringify(cart)
        },
        success: function(response) {
            if (response === 'success') {
                alert('Sale recorded successfully!');
                localStorage.removeItem('cart'); 
                displayCart(); 
            } else {
                alert('Error recording sale.');
            }
        },
        error: function() {
            alert("Error saving sale.");
        }
    });

            let receiptHtml = `
        <div style="width: 80mm; font-family: Arial, sans-serif; color: #333; margin: 10px; background-color: #f9f3e9; padding: 10px; border-radius: 8px; font-size: 12px;">
            <h2 style="font-size: 16px; font-weight: bold; color: #007bff; text-align: center;">RA Vegetables & Fruits</h2>
            <h3 style="font-size: 14px; color: #333; text-align: center;">Receipt</h3>
            <p style="font-size: 12px; color: #666; text-align: center; margin: 10px 0;">Thank you for shopping with us!</p>

            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr>
                        <th style="padding: 8px; text-align: left; font-size: 12px;">Product</th>
                        <th style="padding: 8px; text-align: left; font-size: 12px;">Price</th>
                        <th style="padding: 8px; text-align: left; font-size: 12px;">Qty</th>
                        <th style="padding: 8px; text-align: left; font-size: 12px;">Total</th>
                    </tr>
                </thead>
                <tbody>`;

            cart.forEach(item => {
                let itemTotal = item.price * item.quantity;
                receiptHtml += `
            <tr>
                <td style="padding: 8px; text-align: left; font-size: 12px;">${item.name}</td>
                <td style="padding: 8px; text-align: left; font-size: 12px;">₱${item.price.toFixed(2)}</td>
                <td style="padding: 8px; text-align: left; font-size: 12px;">${item.quantity}</td>
                <td style="padding: 8px; text-align: left; font-size: 12px;">₱${itemTotal.toFixed(2)}</td>
            </tr>`;
            });

            // Receipt footer 
            receiptHtml += `
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" style="padding: 8px; text-align: right; font-weight: bold; font-size: 12px;">Total:</td>
                        <td style="padding: 8px; font-weight: bold; font-size: 12px;">₱${totalAmount.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding: 8px; text-align: right; font-weight: bold; font-size: 12px;">Amount Received:</td>
                        <td style="padding: 8px; font-weight: bold; font-size: 12px;">₱${receivedAmount.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="padding: 8px; text-align: right; font-weight: bold; font-size: 12px;">Change:</td>
                        <td style="padding: 8px; font-weight: bold; font-size: 12px;">₱${(receivedAmount - totalAmount).toFixed(2)}</td>
                    </tr>
                </tfoot>
            </table>

            <p style="font-size: 12px; font-weight: bold; color: #007bff; text-align: center; margin: 10px 0;">Thank you for your purchase!</p>
            <p style="font-size: 10px; color: #666; text-align: center;">Visit us again at RA Vegetables & Fruits.</p>
        </div>`;

            const printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Receipt</title><style>');
            printWindow.document.write(`
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px;
            background-color: #f9f3e9;
            color: #333;
        }
        h2, h3 {
            margin: 0;
            text-align: center;
            color: #007bff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th, table td {
            padding: 8px;
            text-align: left;
            font-size: 12px;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #f2f2f2;
        }
        table td {
            background-color: #fff;
        }
        p {
            font-size: 12px;
            color: #333;
        }
    `);
            printWindow.document.write('</style></head><body>');
            printWindow.document.write(receiptHtml);
            printWindow.document.write('</body></html>');
            printWindow.document.close();

            setTimeout(function() {
                printWindow.print();
            }, 500);
        }
        function updateDateTime() {
    const now = new Date();

    // Get current time in HH:MM:SS format
    const time = now.toLocaleTimeString();

    // Get current date in YYYY-MM-DD format
    const date = now.toLocaleDateString();

    // Update the HTML elements with the current time and date
    document.getElementById('current-time').textContent = `Current Time: ${time}`;
    document.getElementById('current-date').textContent = `Current Date: ${date}`;
}

// Call the function once to display initial time and date
updateDateTime();

// Update the time and date every second
setInterval(updateDateTime, 1000);
   
    </script>
</body>

</html>