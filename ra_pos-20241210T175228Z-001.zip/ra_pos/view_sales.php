<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "ra_pos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM sales ORDER BY transaction_date DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Sales Records</h2>";
    echo "<table border='1'><tr><th>Date</th><th>Total Amount</th><th>Received Amount</th><th>Change</th><th>Products</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row['transaction_date'] . "</td><td>₱" . number_format($row['total_amount'], 2) . "</td><td>₱" . number_format($row['received_amount'], 2) . "</td><td>₱" . number_format($row['change'], 2) . "</td><td>" . htmlspecialchars($row['products']) . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No sales found.";
}

$conn->close();
?>
