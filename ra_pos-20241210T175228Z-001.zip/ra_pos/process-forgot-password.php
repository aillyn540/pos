<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/phpmailer/src/Exception.php';
require __DIR__ . '/phpmailer/src/PHPMailer.php';
require __DIR__ . '/phpmailer/src/SMTP.php';


$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "ra_pos";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

   
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format'); window.location.href = 'forgot-password.php';</script>";
        exit();
    }

    
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        
        $token = bin2hex(random_bytes(50));

        
        $stmt = $conn->prepare("UPDATE users SET reset_token = ? WHERE email = ?");
        $stmt->bind_param("ss", $token, $email);
        if ($stmt->execute()) {
            
            $reset_link = "http://localhost/reset-password.php?token=" . $token;

            $mail = new PHPMailer(true); 
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'rafv53078@gmail.com'; 
                $mail->Password = 'pjyp wkjz pwev bogm'; 
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('rafv53078@gmail.com', 'Your Name');
                $mail->addAddress($email);
                $mail->Subject = 'Password Reset Request';
                $mail->Body    = "Click the following link to reset your password: $reset_link";

                if ($mail->send()) {
                    echo "<script>alert('Password reset link sent to your email.'); window.location.href = 'index.html';</script>";
                } else {
                    echo "<script>alert('Failed to send email. Please try again later.'); window.location.href = 'forgot-password.php';</script>";
                }
            } catch (Exception $e) {
                echo "<script>alert('Email could not be sent. Error: {$mail->ErrorInfo}'); window.location.href = 'forgot-password.php';</script>";
            }
        } else {
            echo "<script>alert('Failed to generate reset token. Please try again later.'); window.location.href = 'forgot-password.php';</script>";
        }
    } else {
        echo "<script>alert('Email not found!'); window.location.href = 'forgot-password.php';</script>";
    }

    $conn->close();
}
?>
