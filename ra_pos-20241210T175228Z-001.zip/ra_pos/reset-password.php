<?php
$token = $_GET['token'];


$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "ra_pos";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Invalid or expired token.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_password = $_POST['password'];
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    
    $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?");
    $stmt->bind_param("ss", $hashed_password, $token);
    if ($stmt->execute()) {
        echo "<script>alert('Password successfully updated!'); window.location.href = 'index.html';</script>";
    } else {
        echo "<script>alert('Failed to update password. Please try again.'); window.location.href = 'reset-password.php?token=$token';</script>";
    }
}

$conn->close();
?>
