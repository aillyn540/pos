<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "ra_pos";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT); 

   
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Username already exists.'); window.location.href = 'index.html';</script>";
    } else {
        
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $user, $pass);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful! Please login.'); window.location.href = 'index.html';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "'); window.location.href = 'index.html';</script>";
        }
    }

    $stmt->close();
}

$conn->close();
?>